import type { DeltaResult, Options } from "./types";
import { Graph } from "./Graph";
import EventEmitter from "node:events";
declare class DeltaCalculator<T> extends EventEmitter {
  _changeEventSource: EventEmitter;
  _options: Options<T>;
  _currentBuildPromise: null | undefined | Promise<DeltaResult<T>>;
  _deletedFiles: Set<string>;
  _modifiedFiles: Set<string>;
  _addedFiles: Set<string>;
  _requiresReset: boolean;
  _graph: Graph<T>;
  constructor(entryPoints: ReadonlySet<string>, changeEventSource: EventEmitter, options: Options<T>);
  end(): void;
  getDelta($$PARAM_0$$: {
    reset: boolean;
    shallow: boolean;
  }): Promise<DeltaResult<T>>;
  getGraph(): Graph<T>;
  _handleMultipleFileChanges: any;
  _handleFileChange: any;
  _getChangedDependencies(modifiedFiles: Set<string>, deletedFiles: Set<string>, addedFiles: Set<string>): Promise<DeltaResult<T>>;
}
export default DeltaCalculator;