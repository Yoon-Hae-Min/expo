/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 *
 * @format
 * @oncall react_native
 */

import type { FileMapDelta, FileMapPlugin, FileMapPluginInitOptions, FileMapPluginWorker, Path } from "../flow-types";
export interface DependencyPluginOptions {
  /** Path to custom dependency extractor module */
  readonly dependencyExtractor?: null | string;
  /** Whether to compute dependencies (performance optimization) */
  readonly computeDependencies: boolean;
  readonly rootDir: Path;
}
declare class DependencyPlugin implements FileMapPlugin<null, ReadonlyArray<string> | null> {
  readonly name: "dependencies";
  constructor(options: DependencyPluginOptions);
  initialize(initOptions: FileMapPluginInitOptions<null, ReadonlyArray<string> | null>): Promise<void>;
  getSerializableSnapshot(): null;
  bulkUpdate(delta: FileMapDelta<null | undefined | ReadonlyArray<string>>): void;
  onNewOrModifiedFile(relativeFilePath: string, pluginData: null | undefined | ReadonlyArray<string>): void;
  onRemovedFile(relativeFilePath: string, pluginData: null | undefined | ReadonlyArray<string>): void;
  assertValid(): void;
  getCacheKey(): string;
  getWorker(): FileMapPluginWorker;
  getDependencies(mixedPath: Path): null | undefined | ReadonlyArray<string>;
}
export default DependencyPlugin;